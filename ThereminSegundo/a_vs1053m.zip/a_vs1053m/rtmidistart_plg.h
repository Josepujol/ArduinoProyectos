#define RTMIDI_PLUGIN_SIZE 28
extern const uint16_t rtmidi_plugin[28];
